-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: remont
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `idcomment` varchar(45) NOT NULL,
  `message` varchar(45) DEFAULT NULL,
  `Master_idMaster` int NOT NULL,
  `request_requestID` int NOT NULL,
  PRIMARY KEY (`idcomment`,`Master_idMaster`,`request_requestID`),
  KEY `fk_Master_has_request_request1_idx` (`request_requestID`),
  KEY `fk_Master_has_request_Master1_idx` (`Master_idMaster`),
  CONSTRAINT `fk_Master_has_request_Master1` FOREIGN KEY (`Master_idMaster`) REFERENCES `master` (`idMaster`),
  CONSTRAINT `fk_Master_has_request_request1` FOREIGN KEY (`request_requestID`) REFERENCES `request` (`requestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES ('1','Всё сделаем!',2,1),('2','Не переживаейте, починим.',3,2),('3','Не переживаейте, починим.',3,3);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `computertechtype`
--

DROP TABLE IF EXISTS `computertechtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `computertechtype` (
  `idcomputerTechType` int NOT NULL,
  `computerTechType_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcomputerTechType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `computertechtype`
--

LOCK TABLES `computertechtype` WRITE;
/*!40000 ALTER TABLE `computertechtype` DISABLE KEYS */;
INSERT INTO `computertechtype` VALUES (1,'Компьютер'),(2,'Ноутбук'),(3,'Мышка'),(4,'Клавиатура');
/*!40000 ALTER TABLE `computertechtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master`
--

DROP TABLE IF EXISTS `master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master` (
  `idMaster` int NOT NULL,
  `Master_name` varchar(45) DEFAULT NULL,
  `Master_surname` varchar(45) DEFAULT NULL,
  `Master_otchestvo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idMaster`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master`
--

LOCK TABLES `master` WRITE;
/*!40000 ALTER TABLE `master` DISABLE KEYS */;
INSERT INTO `master` VALUES (1,'Анастасия','Ремонтникова','Артемовна'),(2,'Полина','Твтвтвт','Ивановна'),(3,'Виктормя','Пиянзина','Дмитриевна');
/*!40000 ALTER TABLE `master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request` (
  `requestID` int NOT NULL,
  `startDate` date DEFAULT NULL,
  `computerTechModel` varchar(45) DEFAULT NULL,
  `problemDescryption` varchar(100) DEFAULT NULL,
  `completionDate` varchar(45) DEFAULT NULL,
  `repairParts` varchar(45) DEFAULT NULL,
  `computerTechType_idcomputerTechType` int NOT NULL,
  `requestStatus_idrequestStatus` int NOT NULL,
  `Master_idMaster` int NOT NULL,
  `User_idUser` int NOT NULL,
  PRIMARY KEY (`requestID`,`computerTechType_idcomputerTechType`,`requestStatus_idrequestStatus`,`Master_idMaster`,`User_idUser`),
  KEY `fk_request_computerTechType_idx` (`computerTechType_idcomputerTechType`),
  KEY `fk_request_requestStatus1_idx` (`requestStatus_idrequestStatus`),
  KEY `fk_request_User1_idx` (`User_idUser`),
  CONSTRAINT `fk_request_computerTechType` FOREIGN KEY (`computerTechType_idcomputerTechType`) REFERENCES `computertechtype` (`idcomputerTechType`),
  CONSTRAINT `fk_request_requestStatus1` FOREIGN KEY (`requestStatus_idrequestStatus`) REFERENCES `requeststatus` (`idrequestStatus`),
  CONSTRAINT `fk_request_User1` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (1,'2023-06-06','RDOR GAMING RAGE H290','Выключается после 10 минут работы',NULL,NULL,1,2,2,7),(2,'2023-05-05','ASUS VivoBook Pro 15 M6500QH-HN034 синий','Сильно шумит и греется',NULL,NULL,2,2,3,8),(3,'2022-07-07','ARDOR GAMING Phantom PRO','Перестало работать колёсико','2023-01-01',NULL,3,3,3,9),(4,'2023-08-02','Dark Project KD83A','Сломались некоторые клавиши',NULL,NULL,4,1,1,8),(5,'2023-08-02','ASUS ROG Strix G15 G513RW-HQ177 серый','Не загружается система',NULL,NULL,2,1,1,9);
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requeststatus`
--

DROP TABLE IF EXISTS `requeststatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requeststatus` (
  `idrequestStatus` int NOT NULL,
  `requestStatus_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idrequestStatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requeststatus`
--

LOCK TABLES `requeststatus` WRITE;
/*!40000 ALTER TABLE `requeststatus` DISABLE KEYS */;
INSERT INTO `requeststatus` VALUES (1,'Новая заявка'),(2,'В процессе ремонта'),(3,'Готова к выдаче');
/*!40000 ALTER TABLE `requeststatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `idRole` int NOT NULL,
  `Role_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idRole`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Техник'),(2,'Менеджер'),(3,'Заказчик'),(4,'Оператор');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `idUser` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `surname` varchar(45) DEFAULT NULL,
  `otchestvo` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `Role_idRole` int NOT NULL,
  PRIMARY KEY (`idUser`,`Role_idRole`),
  KEY `fk_User_Role1_idx` (`Role_idRole`),
  CONSTRAINT `fk_User_Role1` FOREIGN KEY (`Role_idRole`) REFERENCES `role` (`idRole`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Алиса','Минаева','Тимофеевна','89210563128','login1','pass1',2),(2,'Фёдор','Воробьев','Алексеевич','89535078985','login2','pass2',1),(3,'Алёна','Захарова','Андреевна','89210673849','login3','pass3',1),(4,'Василиса','Гусева','Дмитриевна','89990563748','login4','pass4',4),(5,'Даниэль','Миронов','Львович','89994563847','login5','pass5',4),(6,'Роман','Белов','Добрынич','89219567849','login6','pass6',3),(7,'Михаил','Кузин','Родионович','89219567841','login7','pass7',3),(8,'Софья','Ковалева','Владимировна','89219567842','login8','pass8',3),(9,'Вероника','Глухова','Владимировна','89219567843','login9','pass9',3),(10,'Арсений','Князев','Андреевич','89219567844','login10','pass10',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-25  0:48:16
